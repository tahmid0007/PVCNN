from utils.config import configs

configs.model.width_multiplier = 0.25
