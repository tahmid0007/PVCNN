from models.s3dis.pointnet import PointNet
from models.s3dis.pvcnn import PVCNN
from models.s3dis.pvcnnpp import PVCNN2
