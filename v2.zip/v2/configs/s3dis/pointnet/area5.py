from utils.config import configs

configs.dataset.holdout_area = 5
