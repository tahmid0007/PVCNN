from utils.config import Config, configs

configs.seed = 1588147245
configs.deterministic = False

# data configs
configs.data = Config()
configs.data.num_workers = 16
